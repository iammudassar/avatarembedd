jQuery(document).ready(function($) {
    // Initialize Facebook SDK
    window.fbAsyncInit = function() {
        FB.init({
            appId: ifeAdmin.appId,
            cookie: true,
            xfbml: true,
            version: 'v12.0'
        });
    };

    // Handle Facebook Login button click
    $('#ife-fb-login').on('click', function(e) {
        e.preventDefault();
        
        if (!ifeAdmin.appId) {
            alert('Please enter your Facebook App ID first.');
            return;
        }

        FB.login(function(response) {
            if (response.authResponse) {
                // Get user access token
                var accessToken = response.authResponse.accessToken;
                
                // Send token to WordPress
                $.ajax({
                    url: ifeAdmin.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'ife_save_facebook_token',
                        nonce: ifeAdmin.nonce,
                        access_token: accessToken
                    },
                    success: function(response) {
                        if (response.success) {
                            alert('Facebook access token saved successfully!');
                            // Update the access token field
                            $('input[name="ife_facebook_access_token"]').val(accessToken);
                        } else {
                            alert('Error saving access token: ' + response.data.message);
                        }
                    },
                    error: function() {
                        alert('Error saving access token. Please try again.');
                    }
                });
            } else {
                alert('Facebook login cancelled or failed.');
            }
        }, {
            scope: 'instagram_basic,instagram_content_publish,pages_show_list,pages_read_engagement'
        });
    });

    // Handle shortcode copy button
    $('.ife-copy-shortcode').on('click', function() {
        var shortcode = $(this).data('shortcode');
        var $button = $(this);
        
        // Create temporary textarea
        var $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val(shortcode).select();
        document.execCommand('copy');
        $temp.remove();
        
        // Update button state
        $button.addClass('copied');
        $button.html('<span class="dashicons dashicons-yes"></span> ' + ifeAdmin.copied);
        
        // Reset button after 2 seconds
        setTimeout(function() {
            $button.removeClass('copied');
            $button.html('<span class="dashicons dashicons-clipboard"></span> ' + ifeAdmin.copy);
        }, 2000);
    });
}); 