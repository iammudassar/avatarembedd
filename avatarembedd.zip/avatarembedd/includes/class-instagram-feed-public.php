<?php
/**
 * The public-facing functionality of the plugin.
 */
class Instagram_Feed_Public {
    /**
     * Cache duration in seconds (default: 1 hour)
     */
    private $cache_duration = 3600;

    /**
     * Initialize the class and set its properties.
     */
    public function __construct() {
        // Constructor
    }

    /**
     * Initialize the public functionality
     */
    public function init() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('instagram_feed', array($this, 'instagram_feed_shortcode'));
    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     */
    public function enqueue_styles() {
        wp_enqueue_style('instagram-feed-public', IFE_PLUGIN_URL . 'public/css/instagram-feed-public.css', array(), IFE_VERSION);
        
        // Add custom CSS if set
        $custom_css = get_option('ife_custom_css');
        if (!empty($custom_css)) {
            wp_add_inline_style('instagram-feed-public', $custom_css);
        }

        // Add button color styles
        $button_color = get_option('ife_follow_button_color', '#ffffff');
        $button_bg = get_option('ife_follow_button_bg', '#0095f6');
        
        $button_styles = sprintf(
            '.instagram-feed-follow-button { color: %s; background: %s; } .instagram-feed-follow-button:hover { background: %s; }',
            esc_attr($button_color),
            esc_attr($button_bg),
            esc_attr($this->adjust_brightness($button_bg, -10))
        );
        
        wp_add_inline_style('instagram-feed-public', $button_styles);
    }

    /**
     * Adjust color brightness
     */
    private function adjust_brightness($hex, $steps) {
        // Remove # if present
        $hex = ltrim($hex, '#');
        
        // Convert to RGB
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        
        // Adjust brightness
        $r = max(0, min(255, $r + $steps));
        $g = max(0, min(255, $g + $steps));
        $b = max(0, min(255, $b + $steps));
        
        // Convert back to hex
        return sprintf("#%02x%02x%02x", $r, $g, $b);
    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     */
    public function enqueue_scripts() {
        wp_enqueue_script('masonry', 'https://unpkg.com/masonry-layout@4/dist/masonry.pkgd.min.js', array('jquery'), '4.2.2', true);
        wp_enqueue_script('instagram-feed-public', IFE_PLUGIN_URL . 'public/js/instagram-feed-public.js', array('jquery', 'masonry'), IFE_VERSION, true);
    }

    /**
     * Instagram Feed Shortcode
     */
    public function instagram_feed_shortcode($atts) {
        // Get settings
        $access_token = get_option('ife_instagram_access_token');
        $posts_count = get_option('ife_posts_count', 6);
        $display_style = get_option('ife_display_style', 'grid');
        $custom_username = get_option('ife_custom_username');
        $custom_description = get_option('ife_custom_description');

        if (empty($access_token)) {
            return '<p>Please configure your Instagram access token in the plugin settings.</p>';
        }

        // Get Instagram user info (with cache)
        $user_info = $this->get_cached_user_info($access_token);
        if (is_wp_error($user_info)) {
            return '<p>Error fetching Instagram user info: ' . esc_html($user_info->get_error_message()) . '</p>';
        }

        // Get Instagram posts (with cache)
        $posts = $this->get_cached_posts($access_token, $posts_count);
        if (is_wp_error($posts)) {
            return '<p>Error fetching Instagram posts: ' . esc_html($posts->get_error_message()) . '</p>';
        }

        // Start output buffering
        ob_start();
        ?>
        <div class="instagram-feed-wrapper">
            <div class="instagram-feed-header">
                <div class="instagram-feed-profile">
                    <img src="<?php echo esc_url($user_info['profile_picture_url']); ?>" alt="<?php echo esc_attr($user_info['username']); ?>" class="instagram-feed-profile-pic">
                    <div class="instagram-feed-profile-info">
                        <h3 class="instagram-feed-username"><?php echo esc_html($custom_username ?: $user_info['username']); ?></h3>
                        <?php if (!empty($custom_description)) : ?>
                            <p class="instagram-feed-description"><?php echo esc_html($custom_description); ?></p>
                        <?php endif; ?>
                        <a href="https://instagram.com/<?php echo esc_attr($user_info['username']); ?>" target="_blank" class="instagram-feed-follow-button">Follow</a>
                    </div>
                </div>
            </div>
            <div class="instagram-feed-container style-<?php echo esc_attr($display_style); ?>">
                <?php foreach ($posts as $post) : ?>
                    <div class="instagram-feed-item">
                        <a href="<?php echo esc_url($post['permalink']); ?>" target="_blank">
                            <img src="<?php echo esc_url($post['media_url']); ?>" alt="<?php echo esc_attr($post['caption']); ?>">
                            <?php if (!empty($post['caption'])) : ?>
                                <div class="instagram-feed-caption">
                                    <?php echo esc_html(wp_trim_words($post['caption'], 20)); ?>
                                </div>
                            <?php endif; ?>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Get cached user information
     */
    private function get_cached_user_info($access_token) {
        $cache_key = 'ife_user_info_' . md5($access_token);
        $cached_data = get_transient($cache_key);

        if ($cached_data !== false) {
            return $cached_data;
        }

        $user_info = $this->get_instagram_user_info($access_token);
        
        if (!is_wp_error($user_info)) {
            set_transient($cache_key, $user_info, $this->cache_duration);
        }

        return $user_info;
    }

    /**
     * Get cached Instagram posts
     */
    private function get_cached_posts($access_token, $count) {
        $cache_key = 'ife_posts_' . md5($access_token . $count);
        $cached_data = get_transient($cache_key);

        if ($cached_data !== false) {
            return $cached_data;
        }

        $posts = $this->get_instagram_posts($access_token, $count);
        
        if (!is_wp_error($posts)) {
            set_transient($cache_key, $posts, $this->cache_duration);
        }

        return $posts;
    }

    /**
     * Get Instagram user information
     */
    private function get_instagram_user_info($access_token) {
        $api_url = "https://graph.instagram.com/v12.0/me";
        $api_url = add_query_arg(array(
            'fields' => 'id,username,account_type,media_count,profile_picture_url',
            'access_token' => $access_token
        ), $api_url);

        $response = wp_remote_get($api_url);

        if (is_wp_error($response)) {
            return $response;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (empty($data['id'])) {
            return new WP_Error('invalid_token', 'Invalid Instagram access token.');
        }

        return $data;
    }

    /**
     * Get Instagram posts using the Instagram API
     */
    private function get_instagram_posts($access_token, $count) {
        // Get user's media
        $api_url = "https://graph.instagram.com/v12.0/me/media";
        $api_url = add_query_arg(array(
            'fields' => 'id,caption,media_type,media_url,permalink,thumbnail_url,timestamp',
            'access_token' => $access_token,
            'limit' => $count * 2 // Request more posts to account for filtering out reels
        ), $api_url);

        $response = wp_remote_get($api_url);

        if (is_wp_error($response)) {
            return $response;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (empty($data['data'])) {
            return new WP_Error('no_posts', 'No Instagram posts found.');
        }

        // Filter out reels and get only images
        $filtered_posts = array();
        foreach ($data['data'] as $post) {
            if ($post['media_type'] === 'IMAGE' && !strpos(strtolower($post['caption']), '#reel') !== false) {
                $filtered_posts[] = $post;
                if (count($filtered_posts) >= $count) {
                    break;
                }
            }
        }

        return $filtered_posts;
    }
} 