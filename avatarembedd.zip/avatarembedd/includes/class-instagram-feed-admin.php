<?php
/**
 * The admin-specific functionality of the plugin.
 */
class Instagram_Feed_Admin {
    /**
     * Initialize the class and set its properties.
     */
    public function __construct() {
        // Constructor
    }

    /**
     * Initialize the admin functionality
     */
    public function init() {
        add_action('admin_menu', array($this, 'add_plugin_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_styles'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('admin_notices', array($this, 'check_https_notice'));
    }

    /**
     * Check if site is using HTTPS and show notice if not
     */
    public function check_https_notice() {
        if (!is_ssl() && isset($_GET['page']) && $_GET['page'] === 'instagram-feed-settings') {
            ?>
            <div class="notice notice-warning is-dismissible">
                <p><strong>Important:</strong> Instagram Login requires HTTPS. Your site is currently using HTTP. Please enable HTTPS on your site to use the Instagram Login feature.</p>
            </div>
            <?php
        }
    }

    /**
     * Register the administration menu for this plugin into the WordPress Dashboard menu.
     */
    public function add_plugin_admin_menu() {
        add_menu_page(
            'Instagram Feed Settings',
            'Instagram Feed',
            'manage_options',
            'instagram-feed-settings',
            array($this, 'display_plugin_admin_page'),
            'dashicons-instagram',
            30
        );
    }

    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('ife_settings', 'ife_instagram_access_token');
        register_setting('ife_settings', 'ife_posts_count');
        register_setting('ife_settings', 'ife_display_style');
        register_setting('ife_settings', 'ife_custom_username');
        register_setting('ife_settings', 'ife_custom_description');
        register_setting('ife_settings', 'ife_custom_css');
        register_setting('ife_settings', 'ife_follow_button_color');
        register_setting('ife_settings', 'ife_follow_button_bg');

        add_settings_section(
            'ife_main_section',
            'Instagram Feed Settings',
            array($this, 'settings_section_callback'),
            'instagram-feed-settings'
        );

        add_settings_field(
            'ife_instagram_access_token',
            'Instagram Access Token',
            array($this, 'instagram_access_token_callback'),
            'instagram-feed-settings',
            'ife_main_section'
        );

        add_settings_field(
            'ife_custom_username',
            'Custom Username',
            array($this, 'custom_username_callback'),
            'instagram-feed-settings',
            'ife_main_section'
        );

        add_settings_field(
            'ife_custom_description',
            'Custom Description',
            array($this, 'custom_description_callback'),
            'instagram-feed-settings',
            'ife_main_section'
        );

        add_settings_field(
            'ife_follow_button_color',
            'Follow Button Text Color',
            array($this, 'follow_button_color_callback'),
            'instagram-feed-settings',
            'ife_main_section'
        );

        add_settings_field(
            'ife_follow_button_bg',
            'Follow Button Background Color',
            array($this, 'follow_button_bg_callback'),
            'instagram-feed-settings',
            'ife_main_section'
        );

        add_settings_field(
            'ife_posts_count',
            'Number of Posts',
            array($this, 'posts_count_callback'),
            'instagram-feed-settings',
            'ife_main_section'
        );

        add_settings_field(
            'ife_display_style',
            'Display Style',
            array($this, 'display_style_callback'),
            'instagram-feed-settings',
            'ife_main_section'
        );

        add_settings_field(
            'ife_custom_css',
            'Custom CSS',
            array($this, 'custom_css_callback'),
            'instagram-feed-settings',
            'ife_main_section'
        );
    }

    /**
     * Settings section callback
     */
    public function settings_section_callback() {
        echo '<div class="ife-setup-guide">';
        echo '<h3>Setup Guide</h3>';
        echo '<ol>';
        echo '<li><strong>Create an Instagram App:</strong> Go to <a href="https://www.instagram.com/developer/" target="_blank">Instagram Developer Portal</a> and create a new app.</li>';
        echo '<li><strong>Configure Your App:</strong> Set up your app with the required permissions.</li>';
        echo '<li><strong>Get Access Token:</strong> Follow the steps below to get your access token.</li>';
        echo '</ol>';
        echo '</div>';
    }

    /**
     * Instagram Access Token field callback
     */
    public function instagram_access_token_callback() {
        $access_token = get_option('ife_instagram_access_token');
        ?>
        <input type="text" name="ife_instagram_access_token" value="<?php echo esc_attr($access_token); ?>" class="regular-text" />
        <p class="description">Enter your Instagram Access Token</p>

        <div class="ife-token-guide">
            <h4>How to Get Your Instagram Access Token:</h4>
            <ol>
                <li>Go to <a href="https://www.instagram.com/developer/" target="_blank">Instagram Developer Portal</a></li>
                <li>Log in with your Instagram account</li>
                <li>Create a new app or select an existing one</li>
                <li>Go to "Basic Display" → "Basic Display"</li>
                <li>Click "Generate Access Token"</li>
                <li>Authorize your app</li>
                <li>Copy the generated token and paste it above</li>
            </ol>
            <p class="description"><strong>Note:</strong> The token will expire in 60 days. You'll need to generate a new one when it expires.</p>
        </div>
        <?php
    }

    /**
     * Custom Username field callback
     */
    public function custom_username_callback() {
        $custom_username = get_option('ife_custom_username');
        ?>
        <input type="text" name="ife_custom_username" value="<?php echo esc_attr($custom_username); ?>" class="regular-text" />
        <p class="description">Enter a custom username to display instead of your Instagram username. Leave empty to use your Instagram username.</p>
        <?php
    }

    /**
     * Custom Description field callback
     */
    public function custom_description_callback() {
        $custom_description = get_option('ife_custom_description');
        ?>
        <textarea name="ife_custom_description" rows="3" class="large-text"><?php echo esc_textarea($custom_description); ?></textarea>
        <p class="description">Enter a custom description to display under your username. Leave empty to show no description.</p>
        <?php
    }

    /**
     * Posts count field callback
     */
    public function posts_count_callback() {
        $posts_count = get_option('ife_posts_count', 6);
        ?>
        <input type="number" name="ife_posts_count" value="<?php echo esc_attr($posts_count); ?>" min="1" max="20" />
        <p class="description">Number of posts to display (1-20)</p>
        <?php
    }

    /**
     * Display style field callback
     */
    public function display_style_callback() {
        $display_style = get_option('ife_display_style', 'grid');
        ?>
        <select name="ife_display_style">
            <option value="grid" <?php selected($display_style, 'grid'); ?>>Grid</option>
            <option value="collage" <?php selected($display_style, 'collage'); ?>>Collage</option>
            <option value="slider" <?php selected($display_style, 'slider'); ?>>Slider</option>
            <option value="list" <?php selected($display_style, 'list'); ?>>List</option>
        </select>
        <p class="description">Choose how you want to display the Instagram posts</p>
        <?php
    }

    /**
     * Custom CSS field callback
     */
    public function custom_css_callback() {
        $custom_css = get_option('ife_custom_css');
        ?>
        <textarea name="ife_custom_css" rows="10" class="large-text code"><?php echo esc_textarea($custom_css); ?></textarea>
        <p class="description">Enter custom CSS to style your Instagram feed. You can use this to override the default styles.</p>
        <div class="ife-css-guide">
            <h4>Available CSS Classes:</h4>
            <ul>
                <li><code>.instagram-feed-wrapper</code> - Main container</li>
                <li><code>.instagram-feed-header</code> - Header section</li>
                <li><code>.instagram-feed-profile</code> - Profile section</li>
                <li><code>.instagram-feed-profile-pic</code> - Profile picture</li>
                <li><code>.instagram-feed-username</code> - Username</li>
                <li><code>.instagram-feed-description</code> - Description text</li>
                <li><code>.instagram-feed-follow-button</code> - Follow button</li>
                <li><code>.instagram-feed-container</code> - Posts container</li>
                <li><code>.instagram-feed-item</code> - Individual post item</li>
                <li><code>.instagram-feed-caption</code> - Post caption</li>
            </ul>
        </div>
        <?php
    }

    /**
     * Follow Button Color field callback
     */
    public function follow_button_color_callback() {
        $button_color = get_option('ife_follow_button_color', '#ffffff');
        ?>
        <input type="color" name="ife_follow_button_color" value="<?php echo esc_attr($button_color); ?>" />
        <p class="description">Choose the text color for the follow button.</p>
        <?php
    }

    /**
     * Follow Button Background Color field callback
     */
    public function follow_button_bg_callback() {
        $button_bg = get_option('ife_follow_button_bg', '#0095f6');
        ?>
        <input type="color" name="ife_follow_button_bg" value="<?php echo esc_attr($button_bg); ?>" />
        <p class="description">Choose the background color for the follow button.</p>
        <?php
    }

    /**
     * Render the admin page
     */
    public function display_plugin_admin_page() {
        ?>
        <div class="wrap">
            <h1>Instagram Feed Settings</h1>
            
            <div class="ife-shortcode-guide">
                <h2>How to Use</h2>
                <p>To display your Instagram feed on any page or post, use this shortcode:</p>
                <div class="ife-shortcode-box">
                    <code>[instagram_feed]</code>
                    <button type="button" class="button button-secondary ife-copy-shortcode" data-shortcode="[instagram_feed]">
                        <span class="dashicons dashicons-clipboard"></span> Copy
                    </button>
                </div>
                <p class="description">You can add this shortcode to any page, post, or widget area where you want to display your Instagram feed.</p>
            </div>

            <form method="post" action="options.php">
                <?php
                settings_fields('ife_settings');
                do_settings_sections('instagram-feed-settings');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    /**
     * Register the stylesheets for the admin area.
     */
    public function enqueue_admin_styles() {
        wp_enqueue_style('instagram-feed-admin', IFE_PLUGIN_URL . 'admin/css/instagram-feed-admin.css', array(), IFE_VERSION);
    }

    /**
     * Register the JavaScript for the admin area.
     */
    public function enqueue_admin_scripts() {
        if (is_ssl()) {
            wp_enqueue_script('instagram-feed-admin', IFE_PLUGIN_URL . 'admin/js/instagram-feed-admin.js', array('jquery'), IFE_VERSION, true);
            
            // Localize the script with new data
            wp_localize_script('instagram-feed-admin', 'ifeAdmin', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('ife_admin_nonce'),
            ));
        }
    }
} 